﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Refit;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Administration.Controllers
{
    public class AuthorizeAdministratorAttribute : Microsoft.AspNetCore.Authorization.AuthorizeAttribute
    {
        public AuthorizeAdministratorAttribute()
        {
            this.Roles = "Administrator";
        }
    }

    [AuthorizeAdministrator]
    public abstract class AdministrationController : Controller
    {
        protected async Task<ActionResult> Handle(Func<Task> action, ActionResult success, ActionResult failure)
        {
            try
            {
                await action();
                return success;
            }
            catch (ApiException exception)
            {
                ProcessErrors(exception);
               return failure;
            }
        }

        private void ProcessErrors(ApiException exception)
        {
            if (exception.HasContent)
            {
                var errorsList = JsonConvert.DeserializeObject<List<string>>(exception.Content);
                foreach (var error in errorsList)
                {
                    this.ModelState.AddModelError(string.Empty, error);
                }
            }
            else
            {
                this.ModelState.AddModelError(string.Empty, "Internal server error.");
            }
        }
    }
}
