﻿using SoftuniInstagram.Administration.Models;
using SoftuniInstagram.Administration.Services.Images;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Administration.Controllers
{
    public class ImagesController : AdministrationController
    {
        private readonly IImagesService imagesService;

        public ImagesController(IImagesService imgSvc) => imagesService = imgSvc;

        public async Task<IEnumerable<ImagesOutputModel>> Index()
            => await imagesService.UsersImages();

        public async Task RemoveImage(int id)
            => await imagesService.RemoveImage(id);
    }
}
