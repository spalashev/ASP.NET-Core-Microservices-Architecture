﻿namespace SoftuniInstagram.Administration.Models
{
    public class ImagesOutputModel
    {
        public int ImageId { get; set; }
        public string ImageBase64 { get; set; }
    }
}
