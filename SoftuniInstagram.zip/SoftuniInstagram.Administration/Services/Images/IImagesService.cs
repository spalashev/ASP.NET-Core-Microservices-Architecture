﻿using Refit;
using SoftuniInstagram.Administration.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Administration.Services.Images
{
    public interface IImagesService
    {
        [Get("images-for-user")]
        Task<IEnumerable<ImagesOutputModel>> UsersImages();

        [Post("image-remove/{imageId}")]
        Task RemoveImage(int imageId);
    }
}
