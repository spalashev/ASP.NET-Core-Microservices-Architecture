﻿using MassTransit;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SoftuniInstagram.Followers.Data.Models.Request;
using SoftuniInstagram.Followers.Services;
using SoftuniInstagram.Messaging;
using SoftuniInstagram.Services.CurrentToken;
using SoftuniInstagram.Services.Identity.CurrentUser;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Followers.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FollowersController : ControllerBase
    {
        private readonly IFollowerService _followerUser;
        private readonly IBus _publisher;
        private readonly ICurrentUserService _currentUser;
        public FollowersController(IFollowerService followerService, IBus publisher, ICurrentUserService currentUserService)
        {
            _followerUser = followerService;
            _publisher = publisher;
            _currentUser = currentUserService;
        }

        [Authorize]
        [Route("follow_user")]
        [HttpPost]
        public async Task<ActionResult> FollowUser([FromBody] FollowUserRequestModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            await _followerUser.FollowUser(model.UserId);

            if (!_followerUser.IsSuccess)
            {
                return BadRequest(_followerUser.Error);
            }

            await _publisher.Publish(new UserFollowedMessage()
            {
                FollowedUserId = model.UserId,
                FollowerUserId = _currentUser.UserId
            });

            return Ok();
        }

        [Authorize]
        [Route("unfollow_user")]
        [HttpPost]
        public async Task<ActionResult> UnfollowUser([FromBody] UnfollowUserRequestModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            await _followerUser.UnfollowUser(model.UserId);

            if (!_followerUser.IsSuccess)
            {
                return BadRequest(_followerUser.Error);
            }

            return Ok();
        }

        [Authorize]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<string>>> GetCurrentUserFollowers()
        {
            var result = await _followerUser.GetFollowers(null);

            return Ok(result);
        }

        [Authorize]
        [HttpGet]
        [Route("{UserId}")]
        public async Task<ActionResult<IEnumerable<string>>> GetUserFollowers(string UserId)
        {
            var result = await _followerUser.GetFollowers(UserId);

            return Ok(result);
        }

        [Authorize]
        [HttpGet]
        [Route("following_users")]
        public async Task<ActionResult<IEnumerable<string>>> GetCurrentUserFollowingUsers()
        {
            var result = await _followerUser.GetFollowingUsers(null);
            return Ok(result);
        }

        [Authorize]
        [HttpGet]
        [Route("following_users/{userId}")]
        public async Task<ActionResult<IEnumerable<string>>> GetUserFollowingUsers(string userId)
        {
            var result = await _followerUser.GetFollowingUsers(userId);
            return Ok(result);
        }
    }
}
