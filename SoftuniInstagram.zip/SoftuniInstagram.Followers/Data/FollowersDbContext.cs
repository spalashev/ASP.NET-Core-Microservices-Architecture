﻿using Microsoft.EntityFrameworkCore;
using SoftuniInstagram.Followers.Data.Models.Tables;

namespace SoftuniInstagram.Followers.Data
{
    public class FollowersDbContext : DbContext
    {
        public FollowersDbContext(DbContextOptions options) : base(options)
        { }

        public DbSet<Follower> Followers { get; set; }

    }
}
