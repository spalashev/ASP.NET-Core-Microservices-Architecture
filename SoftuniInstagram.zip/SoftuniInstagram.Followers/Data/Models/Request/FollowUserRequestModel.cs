﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace SoftuniInstagram.Followers.Data.Models.Request
{
    public class FollowUserRequestModel
    {
        [JsonPropertyName("user_id")]
        [Required]
        public string UserId { get; set; }
    }
}
