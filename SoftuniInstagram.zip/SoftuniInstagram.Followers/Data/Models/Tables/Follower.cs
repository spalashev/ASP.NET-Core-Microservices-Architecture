﻿using System;

namespace SoftuniInstagram.Followers.Data.Models.Tables
{
    public class Follower
    {
        public int Id { get; set; }
        public DateTime AddedOn { get; set; }
        public int Status { get; set; }
        public string UserId { get; set; }
        public string FollowingUserId { get; set; }
    }
}
