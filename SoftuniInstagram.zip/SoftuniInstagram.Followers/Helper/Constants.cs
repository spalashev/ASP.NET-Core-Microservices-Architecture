﻿namespace SoftuniInstagram.Followers.Helper
{
    public static class Constants
    {
        public enum FollowerStatus
        {
            None = 0,
            Active = 1,
            Removed = 2
        }
    }
}
