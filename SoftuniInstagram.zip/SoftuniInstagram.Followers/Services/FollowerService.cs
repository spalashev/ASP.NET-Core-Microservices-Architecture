﻿using MassTransit;
using Microsoft.EntityFrameworkCore;
using SoftuniInstagram.BaseService;
using SoftuniInstagram.Extensions;
using SoftuniInstagram.Followers.Data;
using SoftuniInstagram.Followers.Data.Models.Tables;
using SoftuniInstagram.Services.Identity.CurrentUser;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static SoftuniInstagram.Followers.Helper.Constants;

namespace SoftuniInstagram.Followers.Services
{
    public class FollowerService : BaseServiceResult, IFollowerService
    {
        private readonly ICurrentUserService _currentUser;
        private readonly FollowersDbContext _dbContext;

        public FollowerService(ICurrentUserService currentUser, FollowersDbContext dbContext) : base()
        {
            _currentUser = currentUser;
            _dbContext = dbContext;
        }

        bool IBaseServiceResult.Failed => base.Failed;

        bool IBaseServiceResult.IsSuccess => base.IsSuccess;

        string IBaseServiceResult.Error => base.Error;

        public async Task<bool> FollowUser(string UserId)
        {
            Init();

            if (_currentUser.IsAdministrator)
            {
                Error = "Administrators cannot follow users.";
                return Failed;
            }

            if (_currentUser.UserId == UserId)
            {
                Error = "Following yourself is not permitted.";
                return Failed;
            }

            var exist = await _dbContext.Followers.FirstOrDefaultAsync(row => row.UserId == _currentUser.UserId && row.FollowingUserId == UserId);

            if (exist != null && exist.Status == FollowerStatus.Active.ToInt())
            {
                Error = $"The current user (id = {_currentUser.UserId}) already follows the user with id = {UserId}.";
                return Failed;
            }

            if (exist != null)
            {
                exist.Status = FollowerStatus.Active.ToInt();
            }
            else
            {
                Follower follower = new Follower()
                {
                    AddedOn = DateTime.Now,
                    UserId = _currentUser.UserId,
                    FollowingUserId = UserId,
                    Status = FollowerStatus.Active.ToInt()
                };
                await _dbContext.Followers.AddAsync(follower);
            }
            await _dbContext.SaveChangesAsync();

            IsSuccess = true;
            return IsSuccess;
        }

        public async Task<bool> UnfollowUser(string UserId)
        {
            Init();

            if(_currentUser.IsAdministrator)
            {
                Error = "This operation is not allowed for Administrators.";
                return Failed;
            }

            if (_currentUser.UserId == UserId)
            {
                Error = "The provided User Id is the same as the one of the current user.";
                return Failed;
            }

            var follower = await _dbContext.Followers
                .FirstOrDefaultAsync(row => row.UserId == _currentUser.UserId && row.FollowingUserId == UserId && row.Status == FollowerStatus.Active.ToInt());

            if (follower == null)
            {
                Error = "The follow does not exist.";
                return Failed;
            }

            follower.Status = FollowerStatus.Removed.ToInt();
            await _dbContext.SaveChangesAsync();

            IsSuccess = true;
            return IsSuccess;
        }

        public async Task<IEnumerable<string>> GetFollowers(string userId)
        {
            string userIdFollowers;

            if (string.IsNullOrEmpty(userId))
            {
                userIdFollowers = _currentUser.UserId;
            }
            else
            {
                userIdFollowers = userId;
            }
            
            return await _dbContext.Followers
                .Where(record => record.FollowingUserId == userIdFollowers && record.Status == FollowerStatus.Active.ToInt())
                .Select(res => res.UserId)
                .ToListAsync();
        }

        public async Task<IEnumerable<string>> GetFollowingUsers(string userId)
        {
            string userIdSearch;

            if (string.IsNullOrEmpty(userId))
            {
                userIdSearch = _currentUser.UserId;
            }
            else
            {
                userIdSearch = userId;
            }

            return await _dbContext.Followers
               .Where(record => record.UserId == userIdSearch && record.Status == FollowerStatus.Active.ToInt())
               .Select(res => res.FollowingUserId)
               .ToListAsync();

        }
    }
}
