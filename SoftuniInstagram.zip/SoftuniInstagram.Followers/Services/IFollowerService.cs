﻿using SoftuniInstagram.BaseService;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Followers.Services
{
    public interface IFollowerService : IBaseServiceResult
    {
        Task<bool> FollowUser(string UserId);
        Task<bool> UnfollowUser(string UserId);
        Task<IEnumerable<string>> GetFollowers(string UserId);
        Task<IEnumerable<string>> GetFollowingUsers(string userId);
    }
}
