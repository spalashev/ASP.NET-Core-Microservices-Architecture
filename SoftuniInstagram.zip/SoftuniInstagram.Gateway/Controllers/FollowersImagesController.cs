﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SoftuniInstagram.Gateway.Models.Response;
using SoftuniInstagram.Gateway.Models.Response.Image;
using SoftuniInstagram.Gateway.Services.Followers;
using SoftuniInstagram.Gateway.Services.Identity;
using SoftuniInstagram.Gateway.Services.Images;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagram.Gateway.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FollowersImagesController : ControllerBase
    {
        private readonly IFollowersService _followersService;
        private readonly IImagesService _imageService;
        private readonly IIdentityService _identityService;

        public FollowersImagesController(IFollowersService followersService, IImagesService imagesService, IIdentityService identityService)
        {
            _followersService = followersService;
            _imageService = imagesService;
            _identityService = identityService;
        }

        [HttpGet]
        [Route("following_users_images")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<FollowingUsersImagesResponseModel>>> GetFollowinUsersPostImages()
        {
            List<FollowingUsersImagesResponseModel> respones = new List<FollowingUsersImagesResponseModel>();
            var followingUsers = await _followersService.GetCurrentUserFollowingUsers();

            if(followingUsers == null || !followingUsers.Any())
            {
                // no data
                return Ok();
            }

            var detailsUsers = await _identityService.GetUsersDetails(followingUsers);

            var images = await _imageService.GetUsersImages(followingUsers);

            if(images == null || detailsUsers == null)
            {
                return Ok();
            }

            foreach (var image in images)
            {
                respones.Add(new FollowingUsersImagesResponseModel()
                {
                    Id = image.Id,
                    DateAdded = image.DateAdded,
                    ImageBase64 = image.ImageBase64,
                    Likes = image.Likes.Select(im => new Models.Response.ImageLikes()
                    {
                        Id = im.Id,
                        ImageId = im.ImageId,
                        LikedOn = im.LikedOn,
                        Status = im.Status,
                        UserId = im.UserId
                    })
                    .ToList(),
                    UserId = image.UserId,
                    Username = detailsUsers.Where(du => du.UserId == image.UserId).FirstOrDefault()?.Username
                });
            }

            return Ok(respones);
        }
    }
}
