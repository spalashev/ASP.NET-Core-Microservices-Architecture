﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SoftuniInstagram.Gateway.Models.Response;
using SoftuniInstagram.Gateway.Services.Followers;
using SoftuniInstagram.Gateway.Services.Identity;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagram.Gateway.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserFollowersController : ControllerBase
    {
        private readonly IFollowersService _followersService;
        private readonly IIdentityService _identityService;
        private readonly IMapper _mapper;

        public UserFollowersController(IFollowersService followersService, IIdentityService identityService, IMapper mapper)
        {
            _followersService = followersService;
            _identityService = identityService;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("my-followers")]
        [Authorize]
        public async Task<ActionResult<List<UserFollowersResponseModel>>> GetCurrentUserFollowers()
        {
            var currentUserFollowers = await _followersService.GetCurrentUserFollowers();

            if (currentUserFollowers == null || currentUserFollowers.Count() <= 0)
            {
                return Ok();
            }

            var usersDetails = await _identityService.GetUsersDetails(currentUserFollowers);
            List<UserFollowersResponseModel> response = _mapper.Map<List<UserFollowersResponseModel>>(usersDetails);
            return Ok(response);
        }

        [HttpGet]
        [Route("user-followers/{UserId}")]
        [Authorize]
        public async Task<ActionResult<List<UserFollowersResponseModel>>> GetUserFollowers(string UserId)
        {
            var userFollowers = await _followersService.GetCurrentUserFollowers(UserId);

            if(userFollowers == null || userFollowers.Count() <= 0)
            {
                return Ok();
            }

            var usersDetails = await _identityService.GetUsersDetails(userFollowers);

            List<UserFollowersResponseModel> response = _mapper.Map<List<UserFollowersResponseModel>>(usersDetails);
            return Ok(response);
        }
    }
}
