﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace SoftuniInstagram.Gateway.Models.Response.Identity
{
    public class UserDetailsResponseModel
    {

        [JsonProperty("user_id")]
        [JsonPropertyName("user_id")]
        public string UserId { get; set; }

        [JsonProperty("username")]
        [JsonPropertyName("username")]
        public string Username { get; set; }

        [JsonProperty("avatar")]
        [JsonPropertyName("avatar")]
        public string ImageBase64 { get; set; }
    }
}
