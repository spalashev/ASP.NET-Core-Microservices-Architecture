﻿using System.Text.Json.Serialization;

namespace SoftuniInstagram.Gateway.Models.Response
{
    public class UserFollowersResponseModel
    {
        [JsonPropertyName("username")]
        public string Username { get; set; }

        [JsonPropertyName("avatar")]
        public string ImageBase64 { get; set; }
    }
}
