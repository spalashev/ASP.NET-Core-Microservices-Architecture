﻿using AutoMapper;
using SoftuniInstagram.Gateway.Models.Response;
using SoftuniInstagram.Gateway.Models.Response.Identity;

namespace SoftuniInstagram.Gateway.Services.Automapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<UserDetailsResponseModel, UserFollowersResponseModel>()
                .ForMember(dest => dest.Username, opt => opt.MapFrom(src => src.Username))
                .ForMember(dest => dest.ImageBase64, opt => opt.MapFrom(src => src.ImageBase64));
        }
    }
}
