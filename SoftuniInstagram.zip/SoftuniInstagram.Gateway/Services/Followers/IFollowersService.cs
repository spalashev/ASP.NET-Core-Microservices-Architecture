﻿using Refit;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Gateway.Services.Followers
{
    public interface IFollowersService
    {
        [Get("/followers/{UserId}")]
        Task<IEnumerable<string>> GetCurrentUserFollowers(string UserId = null);

        [Get("/followers//following_users/{UserId}")]
        Task<IEnumerable<string>> GetFollowingUsers(string UserId);

        [Get("/followers/following_users")]
        Task<IEnumerable<string>> GetCurrentUserFollowingUsers();
    }
}
