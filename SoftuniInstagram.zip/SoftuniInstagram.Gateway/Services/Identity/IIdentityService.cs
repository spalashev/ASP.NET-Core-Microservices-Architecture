﻿using Refit;
using SoftuniInstagram.Gateway.Models.Response.Identity;
using System.Collections.Generic;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace SoftuniInstagram.Gateway.Services.Identity
{
    public interface IIdentityService
    {
        [Get("/identity/users-details")]
        Task<IEnumerable<UserDetailsResponseModel>> GetUsersDetails([Query(CollectionFormat.Multi)] IEnumerable<string> userIds);
    }
}
