﻿using Refit;
using SoftuniInstagram.Gateway.Models.Response.Image;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Gateway.Services.Images
{
    public interface IImagesService
    {
        [Get("/images")]
        Task<IEnumerable<ImageDataResponseModel>> GetCurrentUserImages();

        [Get("/images/user/{UserId}")]
        Task<IEnumerable<ImageDataResponseModel>> GetUserImages(string UserId);

        [Get("/images/users")]
        Task<IEnumerable<ImageDataResponseModel>> GetUsersImages([Query(CollectionFormat.Multi)] IEnumerable<string> userIds);
    }
}
