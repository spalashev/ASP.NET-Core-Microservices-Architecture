﻿namespace SoftuniInstagram.Gateway.Services
{
    public class ServiceEndpoints
    {
        public string FollowersUrl { get; set; }
        public string IdentityUrl { get; set; }
        public string ImagesUrl { get; set; }
    }
}
