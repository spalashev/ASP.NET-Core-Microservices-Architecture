using AutoMapper;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Refit;
using SoftuniInstagram.Extensions;
using SoftuniInstagram.Gateway.Services;
using SoftuniInstagram.Gateway.Services.Automapper;
using SoftuniInstagram.Gateway.Services.Followers;
using SoftuniInstagram.Gateway.Services.Identity;
using SoftuniInstagram.Gateway.Services.Images;
using SoftuniInstagram.Services.CurrentToken;
using SoftuniInstagram.Services.Identity.CurrentUser;

namespace SoftuniInstagram.Gateway
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var serviceEndpoints = Configuration
                .GetSection(nameof(ServiceEndpoints))
                .Get<ServiceEndpoints>(config => config.BindNonPublicProperties = true);

            services.AddTokenAuthentication(Configuration);

            services
                .AddRefitClient<IFollowersService>()
                .WithConfiguration(serviceEndpoints.FollowersUrl);

            services
                .AddRefitClient<IIdentityService>()
                .WithConfiguration(serviceEndpoints.IdentityUrl);

            services
                .AddRefitClient<IImagesService>()
                .WithConfiguration(serviceEndpoints.ImagesUrl);

            services.AddHttpContextAccessor();
            services.AddScoped<ICurrentTokenService, CurrentTokenService>();
            services.AddTransient<JwtHeaderAuthenticationMiddleware>();
            services.AddScoped<ICurrentUserService, CurrentUserService>();

            services.AddSingleton(new MapperConfiguration(mc =>
                {
                    mc.AddProfile(new MappingProfile());
                })
                .CreateMapper());

            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCors(options => options
                .AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod());

            app.UseJwtHeaderAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
