﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SoftuniInstagram.Identity.Data.Models.Request;
using SoftuniInstagram.Identity.Data.Models.Response;
using SoftuniInstagram.Identity.Services.Identity;
using SoftuniInstagram.Services.Identity.CurrentUser;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Identity.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class IdentityController : ControllerBase
    {
        private readonly IIdentityService _identityService;
        private readonly ICurrentUserService _currentUser;
        public IdentityController(IIdentityService identityService, ICurrentUserService currentUser)
        {
            _identityService = identityService;
            _currentUser = currentUser;
        }

        [HttpPost]
        [Route("login")]
        public async Task<ActionResult<LoginResponseModel>> Login([FromBody]LoginRequestModel loginModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid request model");
            }

            var loginResult = await _identityService.Login(loginModel);

            if(loginResult == null)
            {
                return BadRequest("Invalid credentials");
            }

            return Ok(loginResult);
        }

        [HttpPost]
        [Route("register")]
        public async Task<ActionResult<LoginResponseModel>> Register([FromForm]RegisterRequestModel requestModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid request model");
            }

            // Todo : Validate newUserModel
            NewUserDetails newUserModel = JsonConvert.DeserializeObject<NewUserDetails>(requestModel.JsonData);

            await _identityService.Register(newUserModel, requestModel.AvatarUpload);

            if (!_identityService.Success)
            {
                return BadRequest(_identityService.Error);
            }

            return await Login(new LoginRequestModel() 
            { 
                Username = newUserModel.Username, 
                Password = newUserModel.Password 
            });
        }

        [Authorize]
        [Route("test")]
        [HttpGet]
        public ActionResult TestAuthorize()
        {
            return Ok();
        }

        [Authorize]
        [Route("users-details")]
        [HttpGet]
        public async Task<ActionResult<List<UserDetailsResponseModel>>> GetUsersDetails([FromQuery] IEnumerable<string> userIds)
        {
            var response = await _identityService.UsersDetails(userIds);

            return Ok(response);
        }

        [Authorize]
        [Route("details/{userId}")]
        [HttpGet]
        public async Task<ActionResult<UserDetailsResponseModel>> GetDetails(string userId)
        {
            return await _identityService.GetDetails(userId);
        }

        [Authorize]
        [Route("details")]
        [HttpGet]
        public async Task<ActionResult<UserDetailsResponseModel>> GetCurrentUserDetails()
        {
            return await _identityService.GetDetails(_currentUser.UserId);
        }

        [Authorize]
        [Route("users")]
        [Route("users/{username}")]
        [HttpGet]
        public async Task<ActionResult<List<UserDetailsResponseModel>>> SearchUsers(string username)
        {
            return await _identityService.SearchUsers(username);
        }
    }
}
