﻿namespace SoftuniInstagram.Identity.Data.Initial
{
    public interface IInitialDbData
    {
        public void Populate();
    }
}
