﻿using Microsoft.AspNetCore.Identity;
using SoftuniInstagram.Identity.Data.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagram.Identity.Data.Initial
{
    public class InitialDbData : IInitialDbData
    {
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public InitialDbData(UserManager<User> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public void Populate()
        {
            if (_roleManager.Roles.Any())
            {
                return;
            }

            Task
                .Run(async () =>
                {
                    var adminRole = new IdentityRole("Admin");

                    await _roleManager.CreateAsync(adminRole);

                    var adminUser = new User
                    {
                        UserName = "admin",
                        Email = "admin@gram.com",
                        SecurityStamp = "Security"
                    };
                    await _userManager.CreateAsync(adminUser, "Admin1!");
                    await _userManager.AddToRoleAsync(adminUser, "Admin");
                })
                .GetAwaiter()
                .GetResult();
        }
    }
}
