﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace SoftuniInstagram.Identity.Data.Models.Request
{
    public class LoginRequestModel
    {
        [JsonProperty("username")]
        [Required]
        public string Username { get; set; }

        [JsonProperty("password")]
        [Required]
        public string Password { get; set; }
    }
}
