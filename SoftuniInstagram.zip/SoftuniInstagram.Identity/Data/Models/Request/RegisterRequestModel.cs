﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace SoftuniInstagram.Identity.Data.Models.Request
{
    public class RegisterRequestModel
    {
        [FromForm(Name = "image")]
        //[FileExtensions(Extensions = "jpg,jpeg,png,pdf")]
        public IFormFile AvatarUpload { get; set; }

        [FromForm(Name = "data")]
        public string JsonData { get; set; }
    }

    public class NewUserDetails
    {
        [Required]
        [JsonProperty("username")]
        public string Username { get; set; }

        [EmailAddress]
        [JsonProperty("email")]
        public string Email { get; set; }

        [Required]
        [JsonProperty("password")]
        public string Password { get; set; }
    }
}
