﻿using Newtonsoft.Json;

namespace SoftuniInstagram.Identity.Data.Models.Response
{
    public class LoginResponseModel
    {
        [JsonProperty("token")]
        public string Token { get; set; }
    }
}
