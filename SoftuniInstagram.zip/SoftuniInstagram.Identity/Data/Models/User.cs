﻿using Microsoft.AspNetCore.Identity;

namespace SoftuniInstagram.Identity.Data.Models
{
    public class User : IdentityUser
    {
        public string AvatarBase64 { get; set; }
    }
}
