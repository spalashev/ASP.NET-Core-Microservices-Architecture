﻿using SoftuniInstagram.Identity.Data.Models;
using System.Collections.Generic;

namespace SoftuniInstagram.Identity.Services
{
    public interface ITokenGeneratorService
    {
        string GenerateToken(User user, IEnumerable<string> roles = null);
    }
}
