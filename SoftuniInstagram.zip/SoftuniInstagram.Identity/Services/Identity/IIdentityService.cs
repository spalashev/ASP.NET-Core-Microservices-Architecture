﻿using Microsoft.AspNetCore.Http;
using SoftuniInstagram.Identity.Data.Models;
using SoftuniInstagram.Identity.Data.Models.Request;
using SoftuniInstagram.Identity.Data.Models.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.Identity.Services.Identity
{
    public interface IIdentityService
    {
        bool Success { get; }
        string Error { get; }
        Task<LoginResponseModel> Login(LoginRequestModel input);
        Task<User> Register(NewUserDetails registerData, IFormFile image);
        Task<List<UserDetailsResponseModel>> UsersDetails(IEnumerable<string> userIds);
        Task<UserDetailsResponseModel> GetDetails(string userId);
        Task<List<UserDetailsResponseModel>> SearchUsers(string username);
    }
}
