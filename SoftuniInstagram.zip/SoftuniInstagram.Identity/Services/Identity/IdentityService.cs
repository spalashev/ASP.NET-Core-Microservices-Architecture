﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SoftuniInstagram.Identity.Data.Models;
using SoftuniInstagram.Identity.Data.Models.Request;
using SoftuniInstagram.Identity.Data.Models.Response;
using SoftuniInstagram.Services.Identity.CurrentUser;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagram.Identity.Services.Identity
{
    public class IdentityService : IIdentityService
    {
        private readonly UserManager<User> _userManager;
        private readonly ITokenGeneratorService _jwtTokenGenerator;
        private readonly ICurrentUserService _currentUser;

        private bool _success;
        private string _error;

        public IdentityService(UserManager<User> userManager, ITokenGeneratorService jwtTokenGenerator, ICurrentUserService currentUser)
        {
            _userManager = userManager;
            _jwtTokenGenerator = jwtTokenGenerator;
            _currentUser = currentUser;
            Init();
        }

        private void Init()
        {
            _success = false;
        }

        public bool Success => _success;
        public string Error => _error;

        public async Task<LoginResponseModel> Login(LoginRequestModel input)
        {
            Init();
            var user = await _userManager.FindByNameAsync(input.Username);

            if (user == null)
            {
                _error = "User is not found";
                return null;
            }

            bool passwordValidation = await _userManager.CheckPasswordAsync(user, input.Password);
            if (!passwordValidation)
            {
                _error = "Invalid password";
                return null;
            }

            var roles = await _userManager.GetRolesAsync(user);
            var token = _jwtTokenGenerator.GenerateToken(user, roles);

            _success = true;
            return new LoginResponseModel() { Token = token };
        }

        public async Task<User> Register(NewUserDetails registerData, IFormFile image)
        {
            Init();
            var exist = await _userManager.FindByNameAsync(registerData.Username);

            if (exist != null)
            {
                _error = "This user already exist!";
                return null;
            }

            exist = await _userManager.FindByEmailAsync(registerData.Email);
            if (exist != null)
            {
                _error = "User with this email already exist";
                return null;
            }

            if (image.Length <= 0)
            {
                _error = "Image is missing";
                return null;
            }

            // Read Image
            string imageBase64 = ImageConverter.ConvertToBase64(image);

            var newUser = new User()
            {
                UserName = registerData.Username,
                Email = registerData.Email,
                AvatarBase64 = imageBase64
            };

            var createdUser = await _userManager.CreateAsync(newUser, registerData.Password);

            if (!createdUser.Succeeded)
            {
                _error = "User creation failed";
                return null;
            }

            _success = true;
            return newUser;
        }

        public async Task<List<UserDetailsResponseModel>> UsersDetails(IEnumerable<string> userIds)
            =>
            await _userManager.Users.Where(user => userIds.Contains(user.Id)).Select(res => 
                new UserDetailsResponseModel()
                {
                    UserId = res.Id,
                    Username = res.UserName,
                    ImageBase64 = res.AvatarBase64
                })
                .ToListAsync();
        
        public async Task<UserDetailsResponseModel> GetDetails(string userId)
            =>
            await _userManager.Users.Where(user => user.Id == userId).Select(res =>
               new UserDetailsResponseModel()
               {
                   UserId = res.Id,
                   Username = res.UserName,
                   ImageBase64 = res.AvatarBase64
               })
               .FirstOrDefaultAsync();

        public async Task<List<UserDetailsResponseModel>> SearchUsers(string username)
        {
            List<UserDetailsResponseModel> response = new List<UserDetailsResponseModel>();
            var users = await _userManager.Users
                .Where(u => u.Id != _currentUser.UserId && u.UserName != "Admin")
                .ToListAsync();

            if (!string.IsNullOrEmpty(username))
            {
                users = users
                    .Where(u => u.UserName.Contains(username))
                    .ToList();
            }

            foreach (var user in users)
            {
                response.Add(new UserDetailsResponseModel()
                {
                    ImageBase64 = user.AvatarBase64,
                    UserId = user.Id,
                    Username = user.UserName
                });
            }

            return response;
        }
    }
}
