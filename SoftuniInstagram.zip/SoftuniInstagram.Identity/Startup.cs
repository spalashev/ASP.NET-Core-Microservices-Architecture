using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SoftuniInstagram.Identity.Data;
using SoftuniInstagram.Identity.Data.Initial;
using SoftuniInstagram.Identity.Data.Models;
using SoftuniInstagram.Identity.Services.Identity;
using SoftuniInstagram.Identity.Services;
using SoftuniInstagram.Services.Identity.CurrentUser;
using SoftuniInstagram.Extensions;
using System;

namespace SoftuniInstagram.Identity
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<IdentityDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"), sqlOptions =>
                    sqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 10,
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null)));

            services.AddIdentity<User, IdentityRole>(options =>
            {
                options.Password.RequiredLength = 6;
                options.Password.RequireDigit = false;
                options.Password.RequireLowercase = false;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequireUppercase = false;
            }).AddEntityFrameworkStores<IdentityDbContext>();

            services.AddTransient<IInitialDbData, InitialDbData>();
            services.AddTransient<IIdentityService, IdentityService>();
            services.AddTransient<ITokenGeneratorService, TokenGeneratorService>();
            services.Configure<ApplicationSettings>(Configuration.GetSection(nameof(ApplicationSettings)), config => config.BindNonPublicProperties = true);

            // JWT
            services.AddTokenAuthentication(Configuration);       

            services.AddHttpContextAccessor();
            services.AddScoped<ICurrentUserService, CurrentUserService>();

            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IdentityDbContext dbContext, IInitialDbData initalData)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors(options => options
                .AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod());

            app.UseAuthentication();
            app.UseAuthorization();

            dbContext.Database.Migrate();
            initalData.Populate();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
