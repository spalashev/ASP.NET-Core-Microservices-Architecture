﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SoftuniInstagram.ImageService.Data.Models.Response;
using SoftuniInstagram.ImageService.Services;
using SoftuniInstagram.Services.Identity.CurrentUser;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.ImageService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Authorize]
    public class ImagesController : ControllerBase
    {
        private readonly IImageService imageService;
        private readonly ICurrentUserService currentUserService;

        public ImagesController(IImageService imgService, ICurrentUserService currentUserSvc)
        {
            imageService = imgService;
            currentUserService = currentUserSvc;
        }

        [HttpPost]
        [Route("upload")]
        public async Task<ActionResult> UploadImage([FromForm] IFormFile image)
        => await imageService.UploadImage(image, currentUserService.UserId) ? Ok() : StatusCode(StatusCodes.Status500InternalServerError);

        [HttpPost]
        [Route("delete")]
        public async Task<ActionResult> DeleteImage(int imageId)
        => await imageService.DeleteImage(imageId) ? Ok() : StatusCode(StatusCodes.Status500InternalServerError);

        [HttpGet]
        public async Task<IEnumerable<ImageDataResponseModel>> GetCurrentUserImages()
        => await imageService.FindImagesByUserId(currentUserService.UserId);

        [HttpGet]
        [Route("user/{userId}")]
        public async Task<IEnumerable<ImageDataResponseModel>> GetImagesForUser(string userId)
        => await imageService.FindImagesByUserId(userId);

        [HttpGet]
        [Route("users")]
        public async Task<IEnumerable<ImageDataResponseModel>> GetUsersImages([FromQuery] IEnumerable<string> userIds)
            => await imageService.FindImagesByMultipleUsers(userIds);

        [HttpPost]
        [Route("{imageId}/like")]
        public async Task<ActionResult> LikeImage(int imageId)
        => await imageService.ImageAddLike(imageId, currentUserService.UserId) ? Ok() : StatusCode(StatusCodes.Status500InternalServerError);

        [HttpPost]
        [Route("{imageId}/unlike")]
        public async Task<ActionResult> DislikeImage(int imageId)
        {
            await imageService.ImageRemoveLike(imageId, currentUserService.UserId);
            return Ok();
        }

        [HttpGet]
        [Route("{imageId}")]
        public async Task GetImageById(int imageId)
        {
            await imageService.FindImageById(imageId);
        }
    }
}
