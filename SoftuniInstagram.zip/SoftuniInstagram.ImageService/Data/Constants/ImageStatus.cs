﻿namespace SoftuniInstagram.ImageService.Data.Constants
{
    public enum ImageStatus
    {
        Active,
        Deleted
    }
}
