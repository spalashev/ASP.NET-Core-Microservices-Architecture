﻿using Microsoft.EntityFrameworkCore;
using SoftuniInstagram.ImageService.Data.Models;

namespace SoftuniInstagram.ImageService.Data
{
    public class ImagesDbContext : DbContext
    {
        public ImagesDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Image> Images { get; set; }
        public DbSet<ImageLikes> ImageLikes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Image>()
                .HasMany(i => i.Likes)
                .WithOne(l => l.Image)
                .HasForeignKey(il => il.ImageId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
