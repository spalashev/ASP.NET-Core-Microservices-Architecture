﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace SoftuniInstagram.ImageService.Data.Models
{
    public class ImageLikes
    {
        public int Id { get; set; }
        public DateTime LikedOn { get; set; }
        public string UserId { get; set; }
        public int ImageId { get; set; }
        [ForeignKey("ImageId")]
        public Image Image { get; set; }
        public int Status { get; set; }
    }
}
