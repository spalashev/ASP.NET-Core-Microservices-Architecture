﻿using Microsoft.AspNetCore.Http;

namespace SoftuniInstagram.ImageService.Data.Models.Request
{
    public class ImageUploadModel
    {
        IFormFile Image { get; set; }
        string UserId { get; set; }
    }
}
