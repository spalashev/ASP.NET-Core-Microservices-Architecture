﻿using Microsoft.AspNetCore.Http;
using SoftuniInstagram.ImageService.Data.Models;
using SoftuniInstagram.ImageService.Data.Models.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagram.ImageService.Services
{
    public interface IImageService
    {
        Task<bool> UploadImage(IFormFile image, string userId);
        Task<bool> DeleteImage(int imageId);
        Task<Image> FindImageById(int imageId);
        Task<IEnumerable<ImageDataResponseModel>> FindImagesByUserId(string userId);
        Task<IEnumerable<ImageDataResponseModel>> FindImagesByMultipleUsers(IEnumerable<string> userIds);
        Task<bool> ImageAddLike(int imageId, string userId);
        Task ImageRemoveLike(int imageId, string userId);
    }
}
