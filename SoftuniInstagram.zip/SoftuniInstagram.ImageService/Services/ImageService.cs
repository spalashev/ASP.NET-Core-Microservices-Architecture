﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using SoftuniInstagram.ImageService.Data;
using SoftuniInstagram.ImageService.Data.Constants;
using SoftuniInstagram.ImageService.Data.Models;
using SoftuniInstagram.ImageService.Data.Models.Response;
using SoftuniInstagram.Services.Identity.CurrentUser;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagram.ImageService.Services
{
    public class ImageService : IImageService
    {
        private const int ImagesPerPage = 9; // 3 x 3

        private readonly ImagesDbContext db;
        public ImageService(ImagesDbContext imagesDbContext)
        => db = imagesDbContext;

        public async Task<bool> UploadImage(IFormFile image, string userId)
        {
            if (image.Length <= 0)
                return false;

            db.Images.Add(new Image()
            {
                DateAdded = DateTime.UtcNow,
                Status = (int)ImageStatus.Active,
                UserId = userId,
                ImageBase64 = ImageConverter.ConvertToBase64(image)
            });

            await db.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteImage(int imageId)
        {
            Image image = await db.FindAsync<Image>(imageId);
            if (image == null)
                return false;
            
            image.Status = (int)ImageStatus.Deleted; 

            db.Images.Remove(image);
            await db.SaveChangesAsync();

            return true;
        }

        public async Task<Image> FindImageById(int id)
        => await db.Images
            .Where(img => img.Id == id && img.Status == (int)ImageStatus.Active)
            .FirstOrDefaultAsync();

        public async Task<IEnumerable<ImageDataResponseModel>> FindImagesByUserId(string userId)
        => await db.Images
            .Where(img => img.UserId == userId && img.Status == (int)ImageStatus.Active)       
            .OrderByDescending(img => img.DateAdded)
            .Select(image => new ImageDataResponseModel()
            {
                Id = image.Id,
                DateAdded = image.DateAdded,
                ImageBase64 = image.ImageBase64,
                Likes = image.Likes,
                UserId = image.UserId
            })
            .ToListAsync();

        public async Task<IEnumerable<ImageDataResponseModel>> FindImagesByMultipleUsers(IEnumerable<string> userIds)
        => await db.Images
            .Where(img => userIds.Contains(img.UserId) && img.Status == (int)ImageStatus.Active)
            .OrderByDescending(img => img.DateAdded)
            .Select(image => new ImageDataResponseModel()
            {
                Id = image.Id,
                DateAdded = image.DateAdded,
                ImageBase64 = image.ImageBase64,
                Likes = image.Likes,
                UserId = image.UserId
            })
            .ToListAsync();

        public async Task<bool> ImageAddLike(int imageId, string userId)
        {
            var like = await db.ImageLikes.FirstOrDefaultAsync(il => il.ImageId == imageId && il.UserId == userId);

            // A like already exists
            if (like != null)
            {
                // If the like is currently active, then there is nothing else to be done.
                if (like.Status == (int)ImageStatus.Active)
                    return true;

                // Otherwise update the status of the like.
                like.Status = (int)ImageStatus.Active;
            }
            else
            {
                // Obtain the image by its id.
                var image = await FindImageById(imageId);

                if (image == null)
                    return false;

                // Create a like for the image.
                db.ImageLikes.Add(new ImageLikes
                {
                    LikedOn = DateTime.UtcNow,
                    ImageId = image.Id,
                    Image = image,
                    UserId = userId,
                    Status = (int)ImageStatus.Active
                });
            }

            await db.SaveChangesAsync();
            return true;
        }

        public async Task ImageRemoveLike(int imageId, string userId)
        {
            var like = await db.ImageLikes.FirstOrDefaultAsync(il => il.ImageId == imageId && il.UserId == userId);

            if (like == null)
                return;

            like.Status = (int)ImageStatus.Deleted;

            await db.SaveChangesAsync();
        }

    }
}
