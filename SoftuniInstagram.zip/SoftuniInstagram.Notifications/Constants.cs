﻿namespace SoftuniInstagram.Notifications
{
    public class Constants
    {
        public const string AuthenticatedUsersGroup = "AuthenticatedUsers";
    }
}
