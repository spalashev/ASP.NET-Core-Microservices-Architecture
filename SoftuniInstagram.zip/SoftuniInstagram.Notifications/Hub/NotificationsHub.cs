﻿namespace SoftuniInstagram.Notifications.Hub
{
    using Microsoft.AspNetCore.SignalR;
    using System;
    using System.Threading.Tasks;
    using static Constants;
    public class NotificationsHub : Hub
    {
        public override async Task OnConnectedAsync()
        {
            if (Context.User.Identity.IsAuthenticated)
            {
                await Groups.AddToGroupAsync(Context.ConnectionId, AuthenticatedUsersGroup);
            }
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            if (Context.User.Identity.IsAuthenticated)
            {
                await Groups.RemoveFromGroupAsync(Context.ConnectionId, AuthenticatedUsersGroup);
            }
        }
    }
}
