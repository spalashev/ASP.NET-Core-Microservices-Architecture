﻿using MassTransit;
using Microsoft.AspNetCore.SignalR;
using SoftuniInstagram.Messaging;
using SoftuniInstagram.Notifications.Hub;
using System.Threading.Tasks;

namespace SoftuniInstagram.Notifications.Messages
{
    public class UserFollowedConsumer : IConsumer<UserFollowedMessage>
    {
        private readonly IHubContext<NotificationsHub> hub;

        public UserFollowedConsumer(IHubContext<NotificationsHub> hubContext) => hub = hubContext;

        public async Task Consume(ConsumeContext<UserFollowedMessage> context)
            => await hub.Clients
                .User(context.Message.FollowedUserId)
                .SendAsync("new_follower_notification", context.Message);
    }
}
