﻿namespace SoftuniInstagram
{
    public class ApplicationSettings
    {
        public string Secret { get; private set; }
    }
}
