﻿namespace SoftuniInstagram.BaseService
{
    public class BaseServiceResult
    {
        protected bool Failed => false;
        protected bool IsSuccess { get; set; }
        protected string Error { get; set; }

        protected void Init()
        {
            IsSuccess = false;
            Error = string.Empty;
        }
    }
}
