﻿namespace SoftuniInstagram.BaseService
{
    public interface IBaseServiceResult
    {
        public bool Failed { get; }
        public bool IsSuccess { get; }
        public string Error { get; }
    }
}
