﻿using System.Security.Claims;

namespace SoftuniInstagram.Extensions
{
    public static class ClaimsPrincipalExtensions
    {
        public static bool IsAdministrator(this ClaimsPrincipal user)
        {
            return user.IsInRole("Admin");
        }
    }
}
