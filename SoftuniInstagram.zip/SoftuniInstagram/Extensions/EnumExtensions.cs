﻿using System;

namespace SoftuniInstagram.Extensions
{
    public static class EnumExtensions
    {
        public static int ToInt(this Enum enumFollowerStatus)
        {
            return Convert.ToInt32(enumFollowerStatus);
        }
    }
}
