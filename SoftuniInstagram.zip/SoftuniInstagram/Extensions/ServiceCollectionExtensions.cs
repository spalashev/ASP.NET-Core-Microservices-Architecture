﻿using GreenPipes;
using MassTransit;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Text;

namespace SoftuniInstagram.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddTokenAuthentication(this IServiceCollection services, 
            IConfiguration configuration, JwtBearerEvents events = null)
        {
            services
                .AddAuthentication(authentication =>
                {
                    authentication.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    authentication.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(bearer =>
                {
                    bearer.RequireHttpsMetadata = false;
                    bearer.SaveToken = true;
                    bearer.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII
                        .GetBytes(configuration
                            .GetSection(nameof(ApplicationSettings))
                            .GetValue<string>(nameof(ApplicationSettings.Secret)))),
                        ValidateIssuer = false,
                        ValidateAudience = false
                    };

                    if (events != null)
                        bearer.Events = events;
         
                });

            return services;
        }

        public static IServiceCollection AddMessaging(this IServiceCollection services, 
            IConfiguration configuration, params Type[] consumers)
        {
            services.AddMassTransit(mt =>
            {
                foreach (var consumer in consumers)
                {
                    mt.AddConsumer(consumer);
                }

                mt.AddBus(context => Bus.Factory.CreateUsingRabbitMq(rmq =>
                {
                    // Docker config 
                    //rmq.Host("rmqhost", host =>
                    //{
                    //    host.Username("rabbitmq");
                    //    host.Password("rabbitmq");
                    //});
                    rmq.Host("localhost");
                    rmq.UseHealthCheck(context);

                    foreach (var consumer in consumers)
                    {
                        rmq.ReceiveEndpoint(consumer.FullName, endpoint =>
                        {
                            endpoint.PrefetchCount = 6;
                            endpoint.UseMessageRetry(retry => retry.Interval(10, 1000));

                            endpoint.ConfigureConsumer(context, consumer);
                        });
                    }
                }));
            }).AddMassTransitHostedService();

            return services;
        }
    }
}
