﻿using Microsoft.AspNetCore.Http;
using System;
using System.IO;

namespace SoftuniInstagram
{
    public static class ImageConverter
    {
        public static string ConvertToBase64(IFormFile image)
        {
            if (image != null && image.Length > 0)
            {
                using var ms = new MemoryStream();
                image.CopyTo(ms);
                byte[] imageBytes = ms.ToArray();
                return Convert.ToBase64String(imageBytes);
            }

            return null;
        }
    }
}
