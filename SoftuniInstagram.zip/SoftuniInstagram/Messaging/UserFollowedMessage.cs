﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftuniInstagram.Messaging
{
    public class UserFollowedMessage
    {
        public string FollowerUserId { get; set; }
        public string FollowedUserId { get; set; }
    }
}
