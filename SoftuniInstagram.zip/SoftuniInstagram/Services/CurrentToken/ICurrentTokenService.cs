﻿namespace SoftuniInstagram.Services.CurrentToken
{
    public interface ICurrentTokenService
    {
        string Get();
        void Set(string token);
    }
}
