﻿namespace SoftuniInstagram.Services.Identity.CurrentUser
{
    public interface ICurrentUserService
    {
        string UserId { get; }
        bool IsAdministrator { get; }
    }
}
