﻿namespace SoftuniInstagramClient.Core
{
    public static class Constants
    {
        public static string CookieTokenName = "Token";
        public static string ImageHtmlPrefix = "data:image/jpeg;base64,";
    }
}
