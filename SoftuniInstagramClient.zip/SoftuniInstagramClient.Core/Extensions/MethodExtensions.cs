﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Reflection;

namespace SoftuniInstagramClient.Core.Extensions
{
    public static class MethodExtensions
    {
        public static string GetEndpoint<T>(string methodName)
        {
            MethodBase method = typeof(T).GetMethod(methodName);

            var route = method.GetCustomAttributes(true)
                .OfType<RouteAttribute>()
                .FirstOrDefault();

            return route?.Template;
        }
    }
}
