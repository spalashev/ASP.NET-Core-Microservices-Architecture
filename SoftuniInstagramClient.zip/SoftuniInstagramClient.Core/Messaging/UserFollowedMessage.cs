﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftuniInstagramClient.Core.Messaging
{
    public class UserFollowedMessage
    {
        public string FollowerUserId { get; set; }
        public string FollowedUserId { get; set; }
    }
}
