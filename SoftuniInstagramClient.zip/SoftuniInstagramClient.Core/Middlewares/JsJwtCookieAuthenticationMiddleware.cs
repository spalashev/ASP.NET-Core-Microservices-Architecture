﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SoftuniInstagramClient.Core.Services.CurrentUser;
using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Core.Middlewares
{
    public class JsJwtCookieAuthenticationMiddleware : IMiddleware
    {
        private readonly IJsCurrentToken _jsCurrentToken;
        private readonly ICurrentUser _currentUser;

        public JsJwtCookieAuthenticationMiddleware(IJsCurrentToken jsCurrentToken, ICurrentUser currentUser)
        {
            _jsCurrentToken = jsCurrentToken;
            _currentUser = currentUser;
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            string currentToken =  await _jsCurrentToken.Get();

            if (!string.IsNullOrEmpty(currentToken))
            {
                await _currentUser.Initialize();
            }

            await next(context);
        }
    }

    public static class JsJwtCookieAuthenticationMiddlewareExtension
    {
        public static IApplicationBuilder UseJsJwtCookieAuthentication(
             this IApplicationBuilder app)
             => app
                .UseMiddleware<JsJwtCookieAuthenticationMiddleware>();
    }
}
