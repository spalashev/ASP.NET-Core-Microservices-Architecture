﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using SoftuniInstagramClient.Core.Services.CurrentToken;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Core.Middlewares
{
    public class JwtCookieAuthenticationMiddleware : IMiddleware
    {
        private readonly ICurrentTokenService _jsCurrentToken;

        public JwtCookieAuthenticationMiddleware(ICurrentTokenService jsCurrentToken)
            => this._jsCurrentToken = jsCurrentToken;

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            var token = _jsCurrentToken.Get();

            if (token != null)
            {
                this._jsCurrentToken.Set(token);

                context.Request.Headers.Append("Authorization", $"{ "Bearer"} {token}");
            }

            await next.Invoke(context);
        }
    }

    public static class JwtCookieAuthenticationMiddlewareExtensions
    {
        public static IApplicationBuilder UseJwtCookieAuthentication(
            this IApplicationBuilder app)
            => app
                .UseMiddleware<JwtCookieAuthenticationMiddleware>()
                .UseAuthentication();
    }
}
