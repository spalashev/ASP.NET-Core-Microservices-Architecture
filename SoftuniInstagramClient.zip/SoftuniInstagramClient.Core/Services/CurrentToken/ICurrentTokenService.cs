﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftuniInstagramClient.Core.Services.CurrentToken
{
    public interface ICurrentTokenService
    {
        string Get();
        void Set(string token);
    }
}
