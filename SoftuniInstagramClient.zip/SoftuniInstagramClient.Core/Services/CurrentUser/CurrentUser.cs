﻿using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Core.Services.CurrentUser
{
    public class CurrentUser : ICurrentUser
    {
        private readonly IJsCurrentToken _jsCurrentToken;
        public event EventHandler LogoutUser;
        public event EventHandler LoginUser;

        public CurrentUser(IJsCurrentToken jsCurrentToken)
        {
            _jsCurrentToken = jsCurrentToken;
        }

        public string UserId { get ; set; }
        public bool IsAdministrator { get; set; }
        public string UserName { get; set; }

        public async Task Initialize()
        {
            JwtSecurityTokenHandler token = new JwtSecurityTokenHandler();
            var jsToken = await _jsCurrentToken.Get();
            //{unique_name: admin}
            //{role: Admin}
            //{nameid: 38136746-fedd-4606-9005-6f66dcddf331}
            var readedToken = (JwtSecurityToken)token.ReadToken(jsToken);

            this.UserId = readedToken.Claims.FirstOrDefault(claim => claim.Type == "nameid")?.Value;
            this.UserName = readedToken.Claims.FirstOrDefault(claim => claim.Type == "unique_name")?.Value;
            this.IsAdministrator = (readedToken.Claims.FirstOrDefault(claim => claim.Type == "role")?.Value == "Admin");
            OnLoginUser();
        }

        public void Reset()
        {
            UserId = string.Empty;
            UserName = string.Empty;
            IsAdministrator = false;
            OnLogoutUser();
        }

        public void OnLogoutUser()
        {
            this.LogoutUser?.Invoke(this, EventArgs.Empty);
        }

        public void OnLoginUser()
        {
            LoginUser?.Invoke(this, EventArgs.Empty);
        }
    }
}
