﻿using System;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Core.Services.CurrentUser
{
    public interface ICurrentUser
    {
        string UserId { get; set; }
        bool IsAdministrator { get; set; }
        string UserName { get; set; }
        Task Initialize();
        void Reset();

        event EventHandler LogoutUser;
        event EventHandler LoginUser;
    }
}
