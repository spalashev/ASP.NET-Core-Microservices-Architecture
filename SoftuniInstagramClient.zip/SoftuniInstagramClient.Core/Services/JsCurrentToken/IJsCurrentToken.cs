﻿using System.Threading.Tasks;

namespace SoftuniInstagramClient.Core.Services.JsCurrentToken
{
    public interface IJsCurrentToken
    {
        Task Set(string token);
        Task<string> Get();
        Task Remove();
    }
}
