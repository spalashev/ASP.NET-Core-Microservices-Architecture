﻿using Microsoft.JSInterop;
using SoftuniInstagramClient.Core.Services.CurrentToken;
using SoftuniInstagramClient.Core.Services.CurrentUser;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Core.Services.JsCurrentToken
{
    public class JsCurrentToken : IJsCurrentToken
    {
        private readonly IJSRuntime _jsRuntime;
        private readonly ICurrentTokenService _currentToken;

        public JsCurrentToken(IJSRuntime jSRuntime, ICurrentTokenService currentTokenService)
        {
            _jsRuntime = jSRuntime;
            _currentToken = currentTokenService;
        }

        public async Task<string> Get()
        {
            return await _jsRuntime.InvokeAsync<string>("blazorExtensions.GetCookie", Constants.CookieTokenName);
        }

        public async Task Remove()
        {
            await _jsRuntime.InvokeAsync<string>("blazorExtensions.Delete", Constants.CookieTokenName);
        }

        public async Task Set(string token)
        {
            await _jsRuntime.InvokeAsync<string>("blazorExtensions.WriteCookie", Constants.CookieTokenName, token, 1);
            _currentToken.Set(token);
        }
    }
}
