﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace SoftuniInstagramClient.Models.ApiServices.Request.Followers
{
    public class FollowersFollowUserRequestModel
    {
        [JsonPropertyName("user_id")]
        [JsonProperty("user_id")]
        public string UserId { get; set; }
    }
}
