﻿using Newtonsoft.Json;

namespace SoftuniInstagramClient.Models.ApiServices.Request.Identity
{
    public class IdentityLoginRequestModel
    {
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }
    }
}
