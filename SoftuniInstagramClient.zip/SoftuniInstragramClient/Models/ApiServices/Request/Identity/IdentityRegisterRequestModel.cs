﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace SoftuniInstagramClient.Models.ApiServices.Request.Identity
{
    public class IdentityRegisterRequestModel
    {
        [Required]
        [JsonProperty("username")]
        public string Username { get; set; }

        [EmailAddress]
        [JsonProperty("email")]
        public string Email { get; set; }

        [Required]
        [JsonProperty("password")]
        public string Password { get; set; }
    }
}
