﻿using System;
using System.Collections.Generic;

namespace SoftuniInstagramClient.Models.ApiServices.Response.Gateway
{
    public class GatewayImageDataResponseModel
   {
        public int Id { get; set; }
        public DateTime DateAdded { get; set; }
        public string UserId { get; set; }
        public string ImageBase64 { get; set; }
        public string Username { get; set; }
        public List<ImageLikes> Likes { get; set; }
    }

    public class ImageLikes
    {
        public int Id { get; set; }
        public DateTime LikedOn { get; set; }
        public string UserId { get; set; }
        public int ImageId { get; set; }
        public int Status { get; set; }
    }
}
