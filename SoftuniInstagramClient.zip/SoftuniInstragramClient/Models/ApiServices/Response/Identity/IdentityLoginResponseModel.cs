﻿using Newtonsoft.Json;

namespace SoftuniInstagramClient.Models.ApiServices.Response.Identity
{
    public class IdentityLoginResponseModel
    {
        [JsonProperty("token")]
        public string Token { get; set; }
    }
}
