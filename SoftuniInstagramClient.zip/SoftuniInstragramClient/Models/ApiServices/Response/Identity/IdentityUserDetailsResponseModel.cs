﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace SoftuniInstagramClient.Models.ApiServices.Response.Identity
{
    public class IdentityUserDetailsResponseModel
    {
        [JsonPropertyName("user_id")]
        [JsonProperty("user_id")]
        public string UserId { get; set; }

        [JsonPropertyName("username")]
        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonPropertyName("avatar")]
        [JsonProperty("avatar")]
        public string ImageBase64 { get; set; }
    }
}
