﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Models.ApiServices.Response.Image
{
    public class ImageDataResponseModel
    {
        public int Id { get; set; }
        public DateTime DateAdded { get; set; }
        public string UserId { get; set; }
        public string ImageBase64 { get; set; }
        //public List<ImageLikes> Likes { get; set; }
    }
}
