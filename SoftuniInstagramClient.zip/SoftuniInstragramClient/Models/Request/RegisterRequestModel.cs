﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace SoftuniInstagramClient.Models.Request
{
    public class RegisterRequestModel
    {
        [Required]
        [JsonProperty("username")]
        public string Username { get; set; }

        [EmailAddress]
        [JsonProperty("email")]
        public string Email { get; set; }

        [Required]
        [JsonProperty("password")]
        public string Password { get; set; }
    }
}
