﻿using System;
using System.Collections.Generic;

namespace SoftuniInstagramClient.Models.Response
{
    public class ImageDetailsResponseModel
    {
        public int Id { get; set; }
        public DateTime DateAdded { get; set; }
        public string UserId { get; set; }
        public string ImageBase64 { get; set; }
        public List<Likes> Likes { get; set; }
    }

    public class Likes
    {
        public int Id { get; set; }
        public DateTime LikedOn { get; set; }
        public string UserId { get; set; }
        public int ImageId { get; set; }
        public int Status { get; set; }
    }
}
