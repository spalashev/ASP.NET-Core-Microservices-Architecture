﻿using System.Text.Json.Serialization;

namespace SoftuniInstagramClient.Models.Response
{
    public class UserDetailsResponseModel
    {
        [JsonPropertyName("user_id")]
        public string UserId { get; set; }

        [JsonPropertyName("username")]
        public string Username { get; set; }

        [JsonPropertyName("avatar")]
        public string ImageBase64 { get; set; }
    }
}
