﻿namespace SoftuniInstagramClient
{
    public class ServiceEndpoints
    {
        public string Identity { get; private set; }
    }
}
