﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SoftuniInstagramClient.Core.Services.CurrentToken;
using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using SoftuniInstagramClient.Models.ApiServices.Request.Followers;
using System.Collections.Generic;
using System.Threading.Tasks;
using static SoftuniInstagramClient.Core.Extensions.MethodExtensions;

namespace SoftuniInstagramClient.Services.ApiServices.Followers
{
    public class FollowersApiService : HttpBaseApiService, IFollowersApiService
    {
        private readonly IJsCurrentToken _jsCurrentToken;
        private readonly ICurrentTokenService _currentUserToken;

        public FollowersApiService(IConfiguration configuration, IJsCurrentToken jsCurrentToken, ICurrentTokenService currentUserToken)
            :base (configuration["FollowersServiceURL"], jsCurrentToken, currentUserToken)
        {
            _jsCurrentToken = jsCurrentToken;
            _currentUserToken = currentUserToken;
        }

        [Route("/followers")]
        public async Task<IEnumerable<string>> GetCurrentUserFollowers()
        {
            return await GetJson<IEnumerable<string>>(GetEndpoint<FollowersApiService>(nameof(GetCurrentUserFollowers)));
        }

        [Route("/followers")]
        public async Task<IEnumerable<string>> GetUserFollowers(string userId)
        {
            return await GetJson<IEnumerable<string>>(GetEndpoint<FollowersApiService>(nameof(GetUserFollowers)) + $"/{userId}");
        }

        [Route("/followers/follow_user")]
        public async Task FollowUser(string userId)
        {
            await PostRequest(GetEndpoint<FollowersApiService>(nameof(FollowUser)), 
                new FollowersFollowUserRequestModel()
                {
                    UserId = userId
                });
        }

        [Route("/followers/unfollow_user")]
        public async Task UnfollowUser(string userId)
        {
            await PostRequest(GetEndpoint<FollowersApiService>(nameof(UnfollowUser)),
                new FollowersUnfollowUserRequestModel()
                {
                    UserId = userId
                });
        }
    }
}
