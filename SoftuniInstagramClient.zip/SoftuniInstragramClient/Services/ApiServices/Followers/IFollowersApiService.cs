﻿using SoftuniInstagramClient.Models.ApiServices.Request.Followers;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.ApiServices.Followers
{
    public interface IFollowersApiService
    {
        Task<IEnumerable<string>> GetCurrentUserFollowers();
        Task<IEnumerable<string>> GetUserFollowers(string userId);
        Task FollowUser(string userId);
        Task UnfollowUser(string userId);
    }
}
