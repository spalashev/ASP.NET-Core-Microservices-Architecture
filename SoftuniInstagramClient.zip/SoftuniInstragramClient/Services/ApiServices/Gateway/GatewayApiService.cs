﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SoftuniInstagramClient.Core.Services.CurrentToken;
using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using SoftuniInstagramClient.Models.ApiServices.Response.Gateway;
using System.Collections.Generic;
using System.Threading.Tasks;
using static SoftuniInstagramClient.Core.Extensions.MethodExtensions;

namespace SoftuniInstagramClient.Services.ApiServices.Gateway
{
    public class GatewayApiService : HttpBaseApiService, IGatewayApiService
    {
        public GatewayApiService(IConfiguration configuration, IJsCurrentToken jsCurrentToken, ICurrentTokenService currentUserToken)
            : base(configuration["GatewayServiceURL"], jsCurrentToken, currentUserToken)
        {
        }
        
        [Route("/followersimages/following_users_images")]
        public async Task<IEnumerable<GatewayImageDataResponseModel>> GetFollowinUsersPostImages()
        {
            var response = await GetJson<IEnumerable<GatewayImageDataResponseModel>>(GetEndpoint<GatewayApiService>(nameof(GetFollowinUsersPostImages)));
            return response;
        }
    }
}
