﻿using SoftuniInstagramClient.Models.ApiServices.Response.Gateway;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.ApiServices.Gateway
{
    public interface IGatewayApiService
    {
        Task<IEnumerable<GatewayImageDataResponseModel>> GetFollowinUsersPostImages();
    }
}
