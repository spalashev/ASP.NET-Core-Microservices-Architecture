﻿using Microsoft.AspNetCore.Mvc;
using SoftuniInstagramClient.Models.ApiServices.Request.Identity;
using SoftuniInstagramClient.Models.ApiServices.Response.Identity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.ApiServices.Identity
{
    public interface IIdentityApiService
    {
        Task<IdentityLoginResponseModel> Login(IdentityLoginRequestModel loginModel);
        Task<IdentityLoginResponseModel> Register(IdentityRegisterRequestModel registerModel, byte[] imageData);
        Task<IdentityUserDetailsResponseModel> GetDetails(string userId);
        Task<IdentityUserDetailsResponseModel> GetCurrentUserDetails();
        Task<IEnumerable<IdentityUserDetailsResponseModel>> SearchUsers(string username);
    }
}
