﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SoftuniInstagramClient.Core.Services.CurrentToken;
using SoftuniInstagramClient.Core.Services.CurrentUser;
using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using SoftuniInstagramClient.Models.ApiServices.Request.Identity;
using SoftuniInstagramClient.Models.ApiServices.Response.Identity;
using System.Collections.Generic;
using System.Threading.Tasks;
using static SoftuniInstagramClient.Core.Extensions.MethodExtensions;

namespace SoftuniInstagramClient.Services.ApiServices.Identity
{
    public class IdentityApiService : HttpBaseApiService, IIdentityApiService
    {
        private readonly IJsCurrentToken _jsCurrentToken;
        private readonly ICurrentUser _currentUser;

        public IdentityApiService(IConfiguration configuration, IJsCurrentToken jsCurrentToken, ICurrentUser currentUser, ICurrentTokenService currentToken)
            : base(configuration["IdentityServiceURL"], jsCurrentToken, currentToken)
        {
            _jsCurrentToken = jsCurrentToken;
            _currentUser = currentUser;
        }

        [Route("/identity/login")]
        public async Task<IdentityLoginResponseModel> Login(IdentityLoginRequestModel loginModel)
        {
            var response = await PostRequest<IdentityLoginRequestModel, IdentityLoginResponseModel>(GetEndpoint<IdentityApiService>(nameof(Login)), loginModel);

            if (response == null || string.IsNullOrEmpty(response.Token))
            {
                return null;
            }

            await _jsCurrentToken.Set(response.Token);
            await _currentUser.Initialize();
            return response;
        }

        [Route("/identity/register")]
        public async Task<IdentityLoginResponseModel> Register(IdentityRegisterRequestModel registerModel, byte[] imageData)
        {     
            var response = await PostMultipartRequest<IdentityRegisterRequestModel, IdentityLoginResponseModel>(GetEndpoint<IdentityApiService>(nameof(Register)), registerModel, imageData);

            if (response == null || string.IsNullOrEmpty(response.Token))
            {
                return null;
            }

            await _jsCurrentToken.Set(response.Token);
            await _currentUser.Initialize();
            return response;
        }

        [Route("/identity/details")]
        public async Task<IdentityUserDetailsResponseModel> GetDetails(string userId)
        {

            var userDetails = await GetJson<IdentityUserDetailsResponseModel>(
                GetEndpoint<IdentityApiService>(nameof(GetDetails)) + (string.IsNullOrEmpty(userId) ? "" : $"/{userId}"));
            return userDetails;
        }

        [Route("/identity/details")]
        public async Task<IdentityUserDetailsResponseModel> GetCurrentUserDetails()
        {
            var userDetails = await GetJson<IdentityUserDetailsResponseModel>(GetEndpoint<IdentityApiService>(nameof(GetCurrentUserDetails)));
            return userDetails;
        }

        [Route("/identity/users")]
        public async Task<IEnumerable<IdentityUserDetailsResponseModel>> SearchUsers(string username)
        {
            return await GetJson<IEnumerable<IdentityUserDetailsResponseModel>>(
                GetEndpoint<IdentityApiService>(nameof(SearchUsers)) + (string.IsNullOrEmpty(username) ? "" : $"/{username}"));
        }
    }
}
