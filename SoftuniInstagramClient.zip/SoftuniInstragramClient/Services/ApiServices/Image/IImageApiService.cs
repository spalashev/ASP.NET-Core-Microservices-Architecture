﻿using SoftuniInstagramClient.Models.ApiServices.Response.Image;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.ApiServices.Image
{
    public interface IImageApiService
    {
        Task<IEnumerable<ImageDataResponseModel>> GetImagesForCurrentUser();
        Task<IEnumerable<ImageDataResponseModel>> GetImagesForUser(string userId);
        Task UploadImage(byte[] imageData);
    }
}
