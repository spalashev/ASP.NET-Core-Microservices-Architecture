﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SoftuniInstagramClient.Core.Services.CurrentToken;
using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using SoftuniInstagramClient.Models.ApiServices.Response.Image;
using System.Collections.Generic;
using System.Threading.Tasks;
using static SoftuniInstagramClient.Core.Extensions.MethodExtensions;

namespace SoftuniInstagramClient.Services.ApiServices.Image
{
    public class ImageApiService : HttpBaseApiService, IImageApiService
    {
        public ImageApiService(IConfiguration configuration, IJsCurrentToken jsCurrentToken, ICurrentTokenService currentToken) 
            : base(configuration["ImageServiceURL"], jsCurrentToken, currentToken)
        {

        }

        [Route("/images")]
        public async Task<IEnumerable<ImageDataResponseModel>> GetImagesForCurrentUser()
        {
            var response = await GetJson<IEnumerable<ImageDataResponseModel>>(GetEndpoint<ImageApiService>(nameof(GetImagesForCurrentUser)));
            return response;
        }

        [Route("/images/user")]
        public async Task<IEnumerable<ImageDataResponseModel>> GetImagesForUser(string userId)
        {
            var response = await GetJson<IEnumerable<ImageDataResponseModel>>(GetEndpoint<ImageApiService>(nameof(GetImagesForUser)) + $"/{userId}");
            return response;
        }

        [Route("/images/upload")]
        public async Task UploadImage(byte[] imageData)
        {
            await PostMultipartRequest(GetEndpoint<ImageApiService>(nameof(UploadImage)), imageData);
            
        }
    }
}
