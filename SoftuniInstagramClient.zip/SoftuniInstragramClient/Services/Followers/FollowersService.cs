﻿using SoftuniInstagramClient.Services.ApiServices.Followers;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.Followers
{
    public class FollowersService : IFollowersService
    {
        private readonly IFollowersApiService _followersApiService;
        public FollowersService(IFollowersApiService followersApiService)
        {
            _followersApiService = followersApiService;
        }

        public async Task<IEnumerable<string>> GetCurrentUserFollowers()
        {
            return await _followersApiService.GetCurrentUserFollowers();
        }

        public async Task<IEnumerable<string>> GetUserFollowers(string userId)
        {
            return await _followersApiService.GetUserFollowers(userId);
        }

        public async Task FollowUser(string userId)
        {
            await _followersApiService.FollowUser(userId);
        }
        public async Task Unfollow(string userId)
        {
            await _followersApiService.UnfollowUser(userId);
        }
    }
}
