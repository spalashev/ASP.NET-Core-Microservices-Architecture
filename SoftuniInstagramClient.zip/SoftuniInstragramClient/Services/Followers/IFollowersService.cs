﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.Followers
{
    public interface IFollowersService
    {
        Task<IEnumerable<string>> GetCurrentUserFollowers();
        Task<IEnumerable<string>> GetUserFollowers(string userId);
        Task FollowUser(string userId);
        Task Unfollow(string userId);
    }
}
