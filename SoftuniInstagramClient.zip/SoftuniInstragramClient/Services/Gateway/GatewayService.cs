﻿using SoftuniInstagramClient.Core;
using SoftuniInstagramClient.Models.Response;
using SoftuniInstagramClient.Services.ApiServices.Gateway;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.Gateway
{
    public class GatewayService : IGatewayService
    {
        private readonly IGatewayApiService _gatewayApiService;
        public GatewayService(IGatewayApiService gatewayApiService) 
        {
            _gatewayApiService = gatewayApiService;
        }

        public async Task<IEnumerable<FollowingUsersImagesResponseModel>> GetFollowinUsersPostImages()
        {
            var apiResponse = await _gatewayApiService.GetFollowinUsersPostImages();

            List<FollowingUsersImagesResponseModel> response = new List<FollowingUsersImagesResponseModel>();

            if(apiResponse == null || !apiResponse.Any())
            { 
                return response;
            }

            foreach (var apiImage in apiResponse)
            {
                response.Add(new FollowingUsersImagesResponseModel()
                {
                    Id = apiImage.Id,
                    DateAdded = apiImage.DateAdded,
                    ImageBase64 = Constants.ImageHtmlPrefix + apiImage.ImageBase64,
                    //Likes = apiImage.Likes,
                    UserId = apiImage.UserId,
                    Username = apiImage.Username
                });
            }

            return response;
        }
    }
}
