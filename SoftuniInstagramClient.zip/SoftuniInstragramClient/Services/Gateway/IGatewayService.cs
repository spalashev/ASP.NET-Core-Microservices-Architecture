﻿using SoftuniInstagramClient.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.Gateway
{
    public interface IGatewayService
    {
        Task<IEnumerable<FollowingUsersImagesResponseModel>> GetFollowinUsersPostImages();
    }
}
