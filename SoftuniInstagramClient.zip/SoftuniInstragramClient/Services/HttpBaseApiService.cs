﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using SoftuniInstagramClient.Core.Services.CurrentUser;
using SoftuniInstagramClient.Core.Services.CurrentToken;

namespace SoftuniInstagramClient.Services
{
    public class HttpBaseApiService
    {
        public readonly HttpClient _client;
        private readonly string _baseAddress;
        private readonly IJsCurrentToken _jsCurrentToken;
        private readonly ICurrentTokenService _currentToken;

        public HttpBaseApiService(string baseUrl, IJsCurrentToken jsCurrentToken, ICurrentTokenService currentToken)
        {
            _client = new HttpClient();
            _baseAddress = baseUrl;
            _jsCurrentToken = jsCurrentToken;
            _currentToken = currentToken;
        }

        private async Task Init()
        {
            SetAuthorizationToken(_currentToken.Get());
        }

        public async Task<T> GetJson<T>(string endpoint = "")
        {
            await Init();

            _client.DefaultRequestHeaders
               .Accept
               .Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var response = await _client.GetAsync(_baseAddress + endpoint);

            if (response.StatusCode != HttpStatusCode.OK && response.StatusCode != HttpStatusCode.BadRequest)
            {
                return default;
            }

            var jsonResult = response.Content.ReadAsStringAsync().Result;

            if (jsonResult == null || jsonResult.Length <= 0)
            {
                return default;
            }

            return JsonConvert.DeserializeObject<T>(jsonResult);
        }

        public async Task<TOutput> PostMultipartRequest<TInput, TOutput>(string url, TInput dataModel, byte[] imageBytes)
        {
            await Init();
            try
            {
                using (var content = new MultipartFormDataContent())
                {
                    using (var memoryStream = new MemoryStream(imageBytes))
                    {
                        using (var stream = new StreamContent(memoryStream))
                        {
                            content.Add(stream, "image", Guid.NewGuid().ToString() + ".jpg");
                            string jsonRequest = JsonConvert.SerializeObject(dataModel);
                            content.Add(new StringContent(jsonRequest), "data");

                            var response = await _client.PostAsync(_baseAddress + url, content);
                            string contents = await response.Content.ReadAsStringAsync();

                            if(!(response.StatusCode == System.Net.HttpStatusCode.OK || response.StatusCode == System.Net.HttpStatusCode.Created))
                            {
                                return default;
                            }

                            var jsonResult = response.Content.ReadAsStringAsync().Result;
                            if (jsonResult == null || jsonResult.Length <= 0)
                            {
                                return default;
                            }
                            return JsonConvert.DeserializeObject<TOutput>(jsonResult);
                        }
                    }
                }

            }
            catch //(Exception ex)
            {
                return default;
            }
        }

        public async Task PostMultipartRequest(string url, byte[] imageBytes)
        {
            await Init();
            try
            {
                using (var content = new MultipartFormDataContent())
                {
                    using (var memoryStream = new MemoryStream(imageBytes))
                    {
                        using (var stream = new StreamContent(memoryStream))
                        {
                            content.Add(stream, "image", Guid.NewGuid().ToString() + ".jpg");
                            var response = await _client.PostAsync(_baseAddress + url, content);

                            if (!(response.StatusCode == System.Net.HttpStatusCode.OK || response.StatusCode == System.Net.HttpStatusCode.Created))
                            {
                                return;
                            }
                        }
                    }
                }

            }
            catch //(Exception ex)
            {
                return;
            }
        }

        public async Task<TResultOut> PostRequest<TInput, TResultOut>(string url, TInput dataModel/*, string jwt_token = null*/)
        {
            await Init();
            try
            {
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(_baseAddress + url);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";

                var content = new StringContent(JsonConvert.SerializeObject(dataModel), Encoding.UTF8, "application/json");
                var httpResponse = await _client.PostAsync(_baseAddress + url, content);

                if (httpResponse.StatusCode == HttpStatusCode.OK
                    || httpResponse.StatusCode == HttpStatusCode.Created
                    || httpResponse.StatusCode == HttpStatusCode.BadRequest)
                {
                    string responseJson = null;
                    responseJson = await httpResponse.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<TResultOut>(responseJson);
                }

                return default;
            }
            catch (WebException e)
            {
                using (WebResponse response = e.Response)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                    using (Stream data = response.GetResponseStream())
                    using (var reader = new StreamReader(data))
                    {
                        string text = reader.ReadToEnd();
                        return JsonConvert.DeserializeObject<TResultOut>(text);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return default;
            }
        }

        public async Task PostRequest<TInput>(string url, TInput dataModel/*, string jwt_token = null*/)
        {
            await Init();
            try
            {
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(_baseAddress + url);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";

                var content = new StringContent(JsonConvert.SerializeObject(dataModel), Encoding.UTF8, "application/json");
                var httpResponse = await _client.PostAsync(_baseAddress + url, content);

                if (httpResponse.StatusCode == HttpStatusCode.OK
                    || httpResponse.StatusCode == HttpStatusCode.Created
                    || httpResponse.StatusCode == HttpStatusCode.BadRequest)
                {
                }
            }
            catch (WebException e)
            {
                using (WebResponse response = e.Response)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public void SetAuthorizationToken(string token)
        {
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", token);
        }

        public void RemoveAuthorizationToken()
        {
            _client.DefaultRequestHeaders.Authorization = null;
        }
    }
}
