﻿using SoftuniInstagramClient.Models.Request;
using SoftuniInstagramClient.Models.Response;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.Identity
{
    interface IIdentityService
    {
        Task<bool> Login(LoginRequestModel requestModel);

        Task<bool> Register(RegisterRequestModel registerModel, byte[] imageData);
        void Logout();
        Task<UserDetailsResponseModel> GetUserDetails(string userId);
        Task<UserDetailsResponseModel> GetCurrentUserDetails();
        Task<IEnumerable<UserDetailsResponseModel>> SearchUsers(string username);
    }
}
