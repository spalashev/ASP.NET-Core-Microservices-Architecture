﻿using SoftuniInstagramClient.Core;
using SoftuniInstagramClient.Core.Services.CurrentUser;
using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using SoftuniInstagramClient.Models.Request;
using SoftuniInstagramClient.Models.Response;
using SoftuniInstagramClient.Services.ApiServices.Identity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.Identity
{
    public class IdentityService : IIdentityService
    {
        private readonly IIdentityApiService _identityApiService;
        private readonly IJsCurrentToken _jsCurrentToken;
        private readonly ICurrentUser _currentUser;

        public IdentityService(IIdentityApiService identityApiService, IJsCurrentToken jsCurrentToken, ICurrentUser currentUser
            )
        {
            _identityApiService = identityApiService;
            _jsCurrentToken = jsCurrentToken;
            _currentUser = currentUser;
        }

        public async Task<bool> Login(LoginRequestModel requestModel)
        {
            try
            {
                var responseModel = await _identityApiService.Login(new Models.ApiServices.Request.Identity.IdentityLoginRequestModel()
                {
                    Username = requestModel.Username,
                    Password = requestModel.Password
                });

                if (responseModel == null || string.IsNullOrEmpty(responseModel.Token))
                {
                    return false;
                }
                else
                {
                    return true;
                }            
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        public async Task<bool> Register(RegisterRequestModel registerModel, byte[] imageData)
        {
            try
            {
                var response = await _identityApiService.Register(new Models.ApiServices.Request.Identity.IdentityRegisterRequestModel()
                {
                    Email = registerModel.Email,
                    Password = registerModel.Password,
                    Username = registerModel.Username
                }, imageData);

                if(response == null || string.IsNullOrEmpty(response.Token))
                {
                    return false;
                }
                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        public void Logout()
        {
            _jsCurrentToken.Remove();
            _currentUser.Reset();
        }

        public async Task<UserDetailsResponseModel> GetUserDetails(string userId)
        {
            var userDetailsApi = await _identityApiService.GetDetails(userId);

            if(userDetailsApi == null)
            {
                return null;
            }
            return new UserDetailsResponseModel()
            {
                UserId = userDetailsApi.UserId,
                Username = userDetailsApi.Username,
                ImageBase64 = Constants.ImageHtmlPrefix + userDetailsApi.ImageBase64
            };
        }

        public async Task<UserDetailsResponseModel> GetCurrentUserDetails()
        {
            var userDetailsApi = await _identityApiService.GetCurrentUserDetails();

            if (userDetailsApi == null)
            {
                return null;
            }
            return new UserDetailsResponseModel()
            {
                UserId = userDetailsApi.UserId,
                Username = userDetailsApi.Username,
                ImageBase64 = Constants.ImageHtmlPrefix + userDetailsApi.ImageBase64
            };
        }

        public async Task<IEnumerable<UserDetailsResponseModel>> SearchUsers(string username)
        {
            List<UserDetailsResponseModel> resposne = new List<UserDetailsResponseModel>();
            var usersApi = await _identityApiService.SearchUsers(username);

            if(usersApi != null)
            {
                foreach (var user in usersApi)
                {
                    resposne.Add(new UserDetailsResponseModel()
                    {
                        UserId = user.UserId,
                        ImageBase64 = Constants.ImageHtmlPrefix + user.ImageBase64,
                        Username = user.Username
                    });
                }
            }
            return resposne;
        }
    }
}
