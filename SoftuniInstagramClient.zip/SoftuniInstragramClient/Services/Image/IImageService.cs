﻿using SoftuniInstagramClient.Models.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.Image
{
    interface IImageService
    {
        Task<IEnumerable<ImageDetailsResponseModel>> GetImagesForCurrentUser();
        Task<IEnumerable<ImageDetailsResponseModel>> GetImagesForUser(string userId);
        Task UploadImage(byte[] imageData);
    }
}
