﻿using SoftuniInstagramClient.Core;
using SoftuniInstagramClient.Models.Response;
using SoftuniInstagramClient.Services.ApiServices.Image;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SoftuniInstagramClient.Services.Image
{
    public class ImageService : IImageService
    {
        private readonly IImageApiService _imageApiService;
        public ImageService(IImageApiService imageApiService)
        {
            _imageApiService = imageApiService;
        }
        public async Task<IEnumerable<ImageDetailsResponseModel>> GetImagesForCurrentUser()
        {
            var responseApi = await _imageApiService.GetImagesForCurrentUser();
            List<ImageDetailsResponseModel> responseImages = new List<ImageDetailsResponseModel>();

            if (responseApi != null)
            {
                foreach (var image in responseApi)
                {
                    responseImages.Add(new ImageDetailsResponseModel()
                    {
                        DateAdded = image.DateAdded,
                        Id = image.Id,
                        ImageBase64 = Constants.ImageHtmlPrefix + image.ImageBase64,
                        UserId = image.UserId
                    });
                }
            }

            return responseImages;
        }

        public async Task<IEnumerable<ImageDetailsResponseModel>> GetImagesForUser(string userId)
        {
            var responseApi = await _imageApiService.GetImagesForUser(userId);
            List<ImageDetailsResponseModel> responseImages = new List<ImageDetailsResponseModel>();

            if (responseApi != null)
            {
                foreach (var image in responseApi)
                {
                    responseImages.Add(new ImageDetailsResponseModel()
                    {
                        DateAdded = image.DateAdded,
                        Id = image.Id,
                        ImageBase64 = Constants.ImageHtmlPrefix + image.ImageBase64,
                        UserId = image.UserId
                    });
                }
            }

            return responseImages;
        }

        public async Task UploadImage(byte[] imageData)
        {
            await _imageApiService.UploadImage(imageData);
        }
    }
}
