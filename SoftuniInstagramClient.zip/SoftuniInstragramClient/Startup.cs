using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Blazored.Toast;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SoftuniInstagramClient.Core.Middlewares;
using SoftuniInstagramClient.Core.Services.CurrentToken;
using SoftuniInstagramClient.Core.Services.CurrentUser;
using SoftuniInstagramClient.Core.Services.JsCurrentToken;
using SoftuniInstagramClient.Data;
using SoftuniInstagramClient.Services.ApiServices.Followers;
using SoftuniInstagramClient.Services.ApiServices.Gateway;
using SoftuniInstagramClient.Services.ApiServices.Identity;
using SoftuniInstagramClient.Services.ApiServices.Image;
using SoftuniInstagramClient.Services.Followers;
using SoftuniInstagramClient.Services.Gateway;
using SoftuniInstagramClient.Services.Identity;
using SoftuniInstagramClient.Services.Image;

namespace SoftuniInstagramClient
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRazorPages();
            services.AddServerSideBlazor();
            services.AddScoped<ICurrentTokenService, CurrentTokenService>();
            services.AddScoped<IJsCurrentToken, JsCurrentToken>();
            services.AddTransient<JwtHeaderAuthenticationMiddleware>();
            services.AddTransient<JsJwtCookieAuthenticationMiddleware>();
            var serviceEndpoints = this.Configuration
                .GetSection(nameof(ServiceEndpoints))
                .Get<ServiceEndpoints>(config => config.BindNonPublicProperties = true);

            services.AddScoped<IIdentityService, IdentityService>();
            services.AddScoped<IIdentityApiService, IdentityApiService>();
            services.AddScoped<IImageApiService, ImageApiService>();
            services.AddScoped<IImageService, ImageService>();
            services.AddScoped<ICurrentUser, CurrentUser>();
            services.AddScoped<IFollowersApiService, FollowersApiService>();
            services.AddScoped<IFollowersService, FollowersService>();
            services.AddScoped<IGatewayApiService, GatewayApiService>();
            services.AddScoped<IGatewayService, GatewayService>();
            services.AddBlazoredToast();

            services.AddHttpContextAccessor();
            services.AddSingleton<WeatherForecastService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

           // app.UseJsJwtCookieAuthentication();
            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapBlazorHub();
                endpoints.MapFallbackToPage("/_Host");
            });
        }
    }
}
